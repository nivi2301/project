package com.demo.project.service;

import com.demo.project.model.Employee;
import com.demo.project.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

//defining the business logic
@Service
public class EmployeeService {
    @Autowired
    EmployeeRepository employeeRepository;

    //getting all student records
    public List<Employee> getAllEmployee() {
        List<Employee> employees = new ArrayList<Employee>();
        employeeRepository.findAll().forEach(employee -> employees.add(employee));
        return employees;
    }


    public void saveOrUpdate(Employee employee) {
        employeeRepository.save(employee);
    }

    //deleting a specific record
    public void delete(int id) {
        employeeRepository.deleteById(id);
    }
}