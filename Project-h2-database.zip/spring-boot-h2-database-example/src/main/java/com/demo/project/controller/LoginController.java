package com.demo.project.controller;

import com.demo.project.model.Employee;
import com.demo.project.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

@Controller
@SessionAttributes("name")
public class LoginController {

	@Autowired
	EmployeeService employeeService;

	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String showLoginPage(ModelMap model){
		return "login";
	}
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String saveEmplyeeDetails(ModelMap model, @RequestParam int id, @RequestParam String name, @RequestParam String email,@RequestParam String age,
									 @RequestParam String gender, @RequestParam int pincode, @RequestParam String birthday){

		/*model.put("id", id);
		model.put("name", name);
		model.put("email",email);
		model.put("age",age);
		model.put("gender", gender);
		model.put("pincode", pincode);
		model.put("birthday",birthday);*/
		Employee employee = new Employee();
		employee.setId(id);
		employee.setAge(age);
		employee.setName(name);
		employee.setEmail(email);
		employee.setGender(gender);
		employee.setPincode(pincode);
		employee.setBirthday(birthday);
		employeeService.saveOrUpdate(employee);
		return "welcome";
	}


}
